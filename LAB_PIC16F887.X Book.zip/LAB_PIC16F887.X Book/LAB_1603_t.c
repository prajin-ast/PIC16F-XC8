/*-------------------------------------------------------
* File    : LAB_1603_t.c
* Purpose : DHT11 Humiture Sensor
* Author  : Prajin Palangsantikul
-------------------------------------------------------*/
#include <xc.h>
#include <stdio.h>

#define _XTAL_FREQ 20000000
#pragma config FOSC = HS, WDTE = OFF, LVP = OFF

// PIC16F887 I2C port: RC3/SCL, RC4/SDA)
#include "lcd_i2c.h"    // I2C 16x2 Serial LCD Module Display Library
#include "dht11.h"      // DHT11 Humiture Sensor Library

//-------------------------------------------------------
void main(void)
{
  char buf[20];
  SSPMode(MASTER_MODE); // Config i2c master mode
  SSPEN = 1;            // Enables serial port i2c

  setup_timer0();
  lcd_i2c_Init();

  while (1) // Loop forever
  {    
    t1 = micros;
    sprintf(buf,"%lu",t1);
    lcd_i2c_Gotoxy(1,1);
    lcd_i2c_Write(buf);
    
    t2 = micros;
    sprintf(buf,"%lu",t2);
    lcd_i2c_Gotoxy(9,1);
    lcd_i2c_Write(buf);

    t2 = t2 - t1;
    sprintf(buf,"%lu",t2);
    lcd_i2c_Gotoxy(1,2);
    lcd_i2c_Write(buf);

    __delay_ms(1000);
    lcd_i2c_Gotoxy(1,1);
    lcd_i2c_Write("                ");  // blank character
    lcd_i2c_Gotoxy(1,2);
    lcd_i2c_Write("                ");  // blank character
  }
}

