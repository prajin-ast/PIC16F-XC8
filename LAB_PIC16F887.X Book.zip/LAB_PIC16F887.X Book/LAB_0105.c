/*-------------------------------------------------------
* File    : LAB_0105.c
* Purpose : Input/Output port & if..else statement
* Author  : Prajin Palangsantikul
-------------------------------------------------------*/
#include <xc.h>

#define _XTAL_FREQ 20000000
#pragma config FOSC = HS, WDTE = OFF, LVP = OFF

//-------------------------------------------------------
void main(void)
{
  char mem = 0;
  
  ANSEL = 0x00;   // Digital I/O. Pin AN0-AN7
  ANSELH = 0x00;  // Digital I/O. Pin AN8-AN13
  TRISA = 0x01;   // RA0 as input
  TRISB = 0x00;   // PORTB as output
  PORTB = 0x00;   // Clear PORTB
  
  while (1) 
  {
    if (RA0 == 0)
    {
      mem++;
      __delay_ms(200);
    }
    if (mem == 1) { PORTB = 0x01; }  // RB0=1 
    else if (mem == 2) { PORTB = 0x02; } // RB1=1 
    else if (mem == 3) { PORTB = 0x04; } // RB2=1 
    else if (mem == 4) 
    { 
      PORTB = 0x08; // RB3=1
      mem = 0;
    }       
  }  
}
