/*-------------------------------------------------------
* File    : LAB_1101_01.c
* Purpose : CCP1 (Half-Bridge PWM Mode & Dead-Band)
* Author  : Prajin Palangsantikul
-------------------------------------------------------*/
#include <xc.h>

#define _XTAL_FREQ 20000000
#pragma config FOSC = HS, WDTE = OFF, LVP = OFF

// Union used to hold the 10-bit duty cycle */
union PWMDC
{
  unsigned int lpwm;
  char bpwm[2];
};

//-------------------------------------------------------
void SetDCPWM1(unsigned int dutycycle)
{
  union PWMDC DCycle;

  // Save the dutycycle value in the union
  DCycle.lpwm = dutycycle << 6;

  // Write the high byte into CCPR1L
  CCPR1L = DCycle.bpwm[1];

  // Write the low byte into CCP1CON5:4
  CCP1CON = (CCP1CON & 0xCF) | ((DCycle.bpwm[0] >> 2) & 0x30);
}

//-------------------------------------------------------
void main (void)
{ 
  PWM1CONbits.PDC = 120;   // Dead-Band Delay
  
  // Half-Bridge PWM mode
  CCP1CONbits.CCP1M = 12;   // PWM Mode, CCP1M = 1100
  CCP1CONbits.P1M = 2;      // Half-Bridge, P1M0 = 10

  SetDCPWM1(90);  // PWM duty cycle

  // 208.3 kHz PWM Frequency (Resolution 7)
  PR2 = 31;     // PWM Duty Cycle: 0-128  
 
  // Setup Timer2, 1:1 Postscale, Prescaler is 1
  T2CON = 0b00000100;

  TRISD5 = 0; // RD5/P1B
  TRISC2 = 0; // Set RC2/P1A/CCP1
    
  while (1);
}
