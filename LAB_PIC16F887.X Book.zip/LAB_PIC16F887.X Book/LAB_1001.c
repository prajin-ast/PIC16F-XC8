/*-------------------------------------------------------
* File    : LAB_1001.c
* Purpose : CCP1 (Input capture)
* Author  : Prajin Palangsantikul
-------------------------------------------------------*/
#include <xc.h>

#define _XTAL_FREQ 20000000
#pragma config FOSC = HS, WDTE = OFF, LVP = OFF

unsigned int T1Count = 0;

//-------------------------------------------------------
// Interrupt function
void __interrupt() isr(void)			
{
  static char toggle_bit = 0;
  
  if (CCP1IF)  // CCP1 Interrupt Flag bit
  {  
    toggle_bit = !toggle_bit;
    RB0 = toggle_bit;
    T1Count = CCPR1;  // Capture Timer Counter
    CCP1IF = 0;       // Clear the interrupt    
	}
}

//-------------------------------------------------------
void main (void)
{   
  TRISA0 = 0; // output
  TRISB0 = 0; // output

  // Setup Timer1, 1:8 Prescale value
  T1CON = 0b00110001;

  // Capture mode, every rising edge (RC2/CCP1)
  CCP1CON = 0b00000101;
  //Capture mode, every 4th rising edge
  //CCP1CON = 0b00000110; 
  
  // CCP1 Interrupt
  CCP1IE = 1;	// CCP1 Interrupt Enable bit
  CCP1IF = 0;	// CCP1 Interrupt Flag bit
  PEIE = 1;   // Peripheral Interrupt Enable bit
  GIE = 1;    // Global interrupt enable

  while (1)
  {
    RA0 = 1;  __delay_ms(500);
    RA0 = 0;  __delay_ms(500);
  }
}

