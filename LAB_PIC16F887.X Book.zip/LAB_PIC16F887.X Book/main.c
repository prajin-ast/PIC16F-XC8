/* 
 * File:   main.c
 * Author: jin
 *
 * Created on March 31, 2014, 2:55 PM
 */

#include <xc.h>
#include <stdio.h>
#include <stdlib.h>

#pragma config FOSC = HS, WDTE = OFF, LVP = OFF

void wait(void);

/*
 * Main Program
 */
int main(int argc, char** argv)
{
    ANSEL = 0x00;
    TRISA = 0x00;

    while(1)
    {
        RA0 = 1;
        RA1 = 0;
        wait();
        RA0 = 0;
        RA1 = 1;
        wait();
    }
    return (EXIT_SUCCESS);
}

void wait(void)
{
    int i;
    for(i=0; i<25000; i++)
        NOP();
}