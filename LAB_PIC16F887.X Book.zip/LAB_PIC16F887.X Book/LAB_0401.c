/*-------------------------------------------------------
* File    : LAB05_01.c
* Purpose : Timer0 (Timer mode)
* Author  : Prajin Palangsantikul
-------------------------------------------------------*/
#include <xc.h>

#define _XTAL_FREQ 20000000
#pragma config FOSC = HS, WDTE = OFF, LVP = OFF

#define CNT_MS    200

char t0_process = 0;
unsigned char tick = 0;

//-------------------------------------------------------
// Interrupt function all
void __interrupt() isr(void)
{
  if (T0IE && T0IF)	// Timer0 Overflow Interrupt Flag
  {
    if (tick++ > 150) // 2s
    {
      t0_process = 1;
      tick = 0;
    }
    T0IF = 0;  // Clear interrupt flag
  }
}

//-------------------------------------------------------
void main(void)
{
  int cnt_ms = CNT_MS;
  int process = 1;
	
  TRISD = 0;  // PORTB as output
  PORTD = 0;  // Clear port
 
  // Setup Timer0 (Timer mode)
  T0CS = 0;   // Internal instruction cycle clock (FOSC/4)
  PSA = 0;    // Prescaler is assigned to the Timer0 module
  PS0 = 1;    // Prescaler Rate Select PS0-PS2(1:256)
  PS1 = 1;    // 
  PS2 = 1;    // 
  TMR0 = 0;   // Clear Timer0
  
  // Configuration Timer0 Interrupt
  T0IE = 1;   // Enables the Timer0 interrupt
  T0IF = 0;   // Clear Timer0 interrupt flag
  PEIE = 1;   // Enables all unmasked peripheral interrupts
  GIE = 1;    // Enables all unmasked interrupts
	  	  
  while (1)
  {
    if (cnt_ms-- <= 0)
    {
      cnt_ms = CNT_MS;
      if (process == 1) 
      {
        PORTD = 0b00000001;
      } 
      else if (process == 2)
      {
        PORTD = 0b00000010;
      }
      else if (process == 3)
      {
        PORTD = 0b00000100;
      }
      else if (process == 4)
      {
        PORTD = 0b00001000;  	  
      }
      if (process++ > 4)  // Next process
      {
        process = 1;
      }
    } else {
      __delay_ms(1);
    }
    if (t0_process == 1)
    {
      PORTD = 0xff;
      t0_process = 0;
    }
  }	
}
