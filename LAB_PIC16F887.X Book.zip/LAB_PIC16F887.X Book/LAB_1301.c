/*-------------------------------------------------------
* File    : LAB_1301.c
* Purpose : LCD
* Author  : Prajin Palangsantikul
-------------------------------------------------------*/
#include <xc.h>
#include <stdio.h>

#define _XTAL_FREQ 20000000
// Configuration bits
#pragma config FOSC = HS, WDTE = OFF, LVP = OFF

#include "lcd.c"      // LCD Library

//-------------------------------------------------------
void main(void)
{
  unsigned int i;
  unsigned char str[10];
  
	lcd_init();
	lcd_gotoxy(1,1);	  // select first line
	lcd_puts("Up/Down Number");

	while(1)
 	{
	  for(i=0; i<100; i++)
	  {     
      lcd_gotoxy(1,2);
      lcd_puts("          ");   // write blank character
  	  sprintf(str,"%d Up",i);
      lcd_gotoxy(1,2);
      lcd_puts(str);
      __delay_ms(200);
	  }
	  for(i=100; i>0; i--)
	  {
      lcd_gotoxy(1,2);
      lcd_puts("          ");   // write blank character
      sprintf(str,"%d Down",i);
      lcd_gotoxy(1,2);
      lcd_puts(str);
      __delay_ms(200);
	  }   	
	}
}

