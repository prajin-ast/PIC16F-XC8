/*-------------------------------------------------------
* File    : LAB_0902.c
* Purpose : EEPROM 2
* Author  : Prajin Palangsantikul
-------------------------------------------------------*/
#include <xc.h>

#define _XTAL_FREQ 20000000
#pragma config FOSC = HS, WDTE = OFF, LVP = OFF

//-------------------------------------------------------
void main (void)
{   
  unsigned int i;
  unsigned char value[5];

  for(i=0;i<_EEPROMSIZE; i++)
  {
    // Initiate writing value to address
    EEPROM_WRITE(i, i);
    // valid approximately four milliseconds later.
    __delay_ms(4);       
  }
  // read from EEPROM at address
  value[0] = EEPROM_READ(0x41);
  value[1] = EEPROM_READ(0x42);
  value[2] = EEPROM_READ(0x43);
  value[3] = EEPROM_READ(0x44);
  value[4] = EEPROM_READ(0x45);
  
  while(1);
}
