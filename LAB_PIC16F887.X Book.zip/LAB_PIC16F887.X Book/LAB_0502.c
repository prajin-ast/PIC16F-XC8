/*-------------------------------------------------------
* File    : LAB_0502.c
* Purpose : Timer1 (Counter mode & Gate control)
* Author  : Prajin Palangsantikul
-------------------------------------------------------*/
#include <xc.h>

#define _XTAL_FREQ 20000000
#pragma config FOSC = HS, WDTE = OFF, LVP = OFF

#define bitset(var, bitno) ((var) |= 1UL << (bitno))
#define bitclr(var, bitno) ((var) &= ~(1UL << (bitno)))

#define CNT_TICK  (65536-5)

//-------------------------------------------------------
// Interrupt function all
void __interrupt() isr(void)
{
  if (TMR1IE && TMR1IF)	// Timer1 Overflow Interrupt Flag
  {
    bitset(PORTD, 3); // Set RD3
    __delay_ms(500);
    bitclr(PORTD, 3); // Clear RD3
    TMR1 = CNT_TICK;
    TMR1IF = 0;  // Clear interrupt flag
  }
}

//-------------------------------------------------------
void main(void)
{
  unsigned int cnt_ms = 0;
    
	TRISD = 0;    // PORTB as output
  PORTD = 0x01; // Clear port
  ANS13 = 0;    // RB5 as digital input
  TRISB5 = 1;   // RB5 as input (T1G)
  TRISC0 = 1;   // RC0 as input (T1CKI)
 
  // Setup Timer1 (Counter mode)
  TMR1GE = 1;   // Use the Timer1 gate (T1G/RB5 pin)
  T1GINV = 0;   // Timer1 gate is active-low
  T1CKPS0 = 0;  // Timer1 Input Clock Prescale Select (1:1)
  T1CKPS1 = 0;  //
  TMR1CS = 1;   // External clock from T1CKI pin (on the rising edge)
  TMR1ON = 1;   // Enables Timer1
  TMR1 = CNT_TICK;
  
  // Configuration Timer1 Interrupt
  TMR1IE = 1;   // Enables the Timer1 interrupt
  TMR1IF = 0;   // Clear Timer1 interrupt flag
  PEIE = 1;	    // Enables all unmasked peripheral interrupts
  GIE = 1;	    // Enables all unmasked interrupts
			  
	while (1)
	{
    if (cnt_ms++ > 500)
    {
      RD0 = !RD0;
      RD1 = !RD1;
      cnt_ms = 0;
    } else {
      if (cnt_ms == 250)
      {
        RD2 = !RD2;
      }
      __delay_ms(1);
    }    
	}	
}
