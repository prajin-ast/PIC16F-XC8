/* 
 * File:   main.c
 * Author: Prajin Palangsantikul
 *
 * Created on March 30, 2014, 1:30 PM
 */

#include <xc.h>
#include <stdio.h>
#include <stdlib.h>

// This definition is required to calibrate __delay_us() and __delay_ms()
#define _XTAL_FREQ 20000000

// CONFIG1
#pragma config FOSC = HS        // HS oscillator
#pragma config WDTE = OFF       // Watchdog Timer Disable
#pragma config LVP = OFF        // Low Voltage Programming Disable

/*
 * 
 */
int main(int argc, char** argv)
{
    unsigned int i;

    TRISA = 0x00;
    TRISB = 0x00;

    while(1)
    {
        RA0 = 0;
        RB0 = 1;
        __delay_ms(250);
        RA0 = 1;
        RB0 = 0;
        __delay_ms(250);
    }
    return (EXIT_SUCCESS);
}
