/*-------------------------------------------------------
* File    : LAB_0302.c
* Purpose : Serial I/O communications peripheral (Interrupt)
* Author  : Prajin Palangsantikul
-------------------------------------------------------*/
#include <xc.h>

#define _XTAL_FREQ 20000000
#pragma config FOSC = HS, WDTE = OFF, LVP = OFF

#include "usart.c"  // USART Library, 9600:8:N:1

char rx_flag = 0;
char ch;

//-------------------------------------------------------
// Interrupt function all
void __interrupt() isr(void)
{
  if (RCIE && RCIF)	// EUSART receive buffer
  {
    RCIF = 0;       // Clear interrupt flag
    ch = RCREG;
    rx_flag = 1;
  }
  if (TXIE && TXIF) // EUSART transmit buffer
  {
    TXIF = 0;       // Clear interrupt flag
  }
}

//-------------------------------------------------------
void main(void)
{
  char bit_mark = 1;
  char cnt_ms = -1;
	
  ANSEL = 0;    // PORTA as digital output
  TRISA = 0x00; // PORTA as output

  INTCON = 0;   // Disable all interrupts.
  init_comms(); // Set up the UART
  
  printf("\n\rInterrupt Serial port");
  
  // Configuration USART Interrupt
  RCIE = 1;   // Enables the EUSART receive interrupt
  TXIE = 0;   // Disables the EUSART transmit interrupt
  RCIF = 0;   // Clear interrupt flag
  TXIF = 0;   // Clear interrupt flag
  PEIE = 1;   // Enables all unmasked peripheral interrupts
  GIE = 1;    // Enables all unmasked interrupts
	  	  
  while (1)
  {
    if (cnt_ms-- <= 0)
    {
      PORTA = bit_mark;
      bit_mark = bit_mark << 1;
      if (bit_mark == 0x10)
      {
        bit_mark = 1;
      }
      cnt_ms = 50;
    } else 
    {
      __delay_ms(1);
    }
  	
    if (rx_flag == 1)
    {
      printf("\n\rInterrupt rx: ");
      _putch(ch);
      rx_flag = 0;
    }    
  }
}