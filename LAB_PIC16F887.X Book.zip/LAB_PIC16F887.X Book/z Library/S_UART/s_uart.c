//-----------------------------------------------:
// File     : s_uart.c
// Purpose  : Test Soft UART 
// Author   : Prajin Palangsantikul
// Compiler : HI-TECH C Compiler
// Target   : PIC12F683 (or PIC12F675)
//-----------------------------------------------:
#include <stdio.h>
#include <htc.h>

#define _XTAL_FREQ  4000000

__CONFIG( FOSC_INTOSCIO & PWRTE_ON & BOREN_OFF & WDTE_OFF & MCLRE_OFF & CP_OFF );

//-----------------------------------------------:Function Library
#define LITE_MODE     1
#include "s_serial.c"           // Serial Standard Input/Output

//-----------------------------------------------:
void main(void)
{  
  INTCON = 0;     // Disable interrupts.	
  CMCON0 = 0xF7;  // Turn off comparators
  ANSEL = 0;      // All GPIO digital  
  GPIO = 0;       // Clear GPIO
  TRISIO4 = 0;    // Set GPIO4 output  
  printf("\fTest Serial PIC12F683");
  //put_string("\fTest Serial PIC12F683");
  
  while(1)
  { 
    //printf("\n\rTest.. = %u", range++);
    //put_string("Test...  ");
    //putch('B');
    //__delay_ms(100);
    put_string("\n\rInput : ");
    getche();
  }
}

