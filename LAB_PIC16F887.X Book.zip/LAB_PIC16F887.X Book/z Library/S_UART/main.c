#include <stdio.h>
#include <htc.h>

/* A simple demonstration of serial communications which
 * uses the bit-banging implementation of a serial communications.
 * Useful for PIC16Cxxx series of devices, or if USART is already
 * in use. */
void main(void){
	unsigned char input;

	INTCON=0;	// purpose of disabling the interrupts.

	printf("\rPress a key and I will echo it back:\n");
	while(1){
		input = getch();	// read a response from the user
		printf("\rI detected [%c]",input);	// echo it back
	}
}
