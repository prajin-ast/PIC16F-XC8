/*-------------------------------------------------------
* File    : LAB01_01.c
* Purpose : Output port
* Author  : Prajin Palangsantikul
-------------------------------------------------------*/
#include <16f887.h>

// Configuration bits
#fuses HS, NOWDT, NOLVP
#use delay(clock = 20M)

void main(void)
{
  output_high(PIN_A0);
  
  while (TRUE);    // Loop forever   
}
