/*-------------------------------------------------------
* File    : LAB01_01.c
* Purpose : Output port
* Author  : Prajin Palangsantikul
-------------------------------------------------------*/
#include <htc.h>

#define _XTAL_FREQ 20000000
// Configuration bits
__CONFIG(FOSC_HS & WDTE_OFF & LVP_OFF);

//-------------------------------------------------------
void main(void)
{
	ANSEL = 0x00;   // Digital I/O. Pin AN0-AN7
	TRISA = 0x00;   // PORTA pin configured as an output
	PORTA = 0x00;   // Clear PORTA
		
	while (1) // Loop forever
	{
    RA0 = 1;    // High	
    __delay_ms(100);
    RA0 = 0;    // Low
    __delay_ms(100);
	}
}
