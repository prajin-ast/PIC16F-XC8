#include <htc.h>
#define _XTAL_FREQ 20000000
__CONFIG(FOSC_HS & WDTE_OFF & LVP_OFF);
#include "lcd.h"

void
main(void)
{
	lcd_init();
	lcd_goto(0);	// select first line
	lcd_puts("12345678");
	//__delay_ms(100);
	lcd_goto(0x40);	// Select second line
	lcd_puts("Hello world");

	for(;;);
}
