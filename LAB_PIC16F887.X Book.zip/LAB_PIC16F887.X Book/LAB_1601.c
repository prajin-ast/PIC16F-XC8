/*-------------------------------------------------------
* File    : LAB_1601.c
* Purpose : I2C 1602 Serial LCD
* Author  : Prajin Palangsantikul
-------------------------------------------------------*/
#include <xc.h>
#include <stdio.h>

#define _XTAL_FREQ 20000000
#pragma config FOSC = HS, WDTE = OFF, LVP = OFF

// PIC16F887 I2C port: RC3/SCL, RC4/SDA)
#include "lcd_i2c.h"    // I2C 16x2 Serial LCD Module Display Library

//-------------------------------------------------------
void main(void)
{
  char buf[20];
  unsigned char cnt = 0;
  
  SSPMode(MASTER_MODE); // Config i2c master mode
  SSPEN = 1;            // Enables serial port i2c
  
  lcd_i2c_Init();
  lcd_i2c_Write("* APPSOFTTECH *");
  lcd_i2c_Gotoxy(1,2);
  lcd_i2c_Write("number:");

  while (1) // Loop forever
  {
      sprintf(buf,"%d",cnt++);
      lcd_i2c_Gotoxy(8,2);
      lcd_i2c_Write(buf);
      __delay_ms(500);
      lcd_i2c_Gotoxy(8,2);
      lcd_i2c_Write("   ");    // clear character
  }  
}
