/*-------------------------------------------------------
* File    : LAB_0108.c
* Purpose : Input/Output port
* Author  : Prajin Palangsantikul
-------------------------------------------------------*/
#include <xc.h>

#define _XTAL_FREQ 20000000
#pragma config FOSC = HS, WDTE = OFF, LVP = OFF

//-------------------------------------------------------
void main(void)
{
  char n, n_bit;
  
	TRISC = 0x00;   // PORTC as output
	PORTC = 0x00;   // Clear PORTC
  n_bit = 0x01;
  
	while (1)
	{    
    for (n=0; n<4; n++)
    {
      PORTC = n_bit;
      n_bit = n_bit << 1; // shift to left
      __delay_ms(100);
    }
    
    for (n=0; n<4; n++)
    {
      PORTC = n_bit;
      n_bit = n_bit >> 1; // shift to right
      __delay_ms(100);
    }  	
	}
}