/*-------------------------------------------------------
* File    : LAB_1003.c
* Purpose : CCP1 (PWM)
* Author  : Prajin Palangsantikul
-------------------------------------------------------*/
#include <xc.h>

#define _XTAL_FREQ 20000000
#pragma config FOSC = HS, WDTE = OFF, LVP = OFF

// Union used to hold the 10-bit duty cycle */
union PWMDC
{
  unsigned int lpwm;
  char bpwm[2];
};

//-------------------------------------------------------
void SetDCPWM1(unsigned int dutycycle)
{
  union PWMDC DCycle;

  // Save the dutycycle value in the union
  DCycle.lpwm = dutycycle << 6;

  // Write the high byte into CCPR1L
  CCPR1L = DCycle.bpwm[1];

  // Write the low byte into CCP1CON5:4
  CCP1CON = (CCP1CON & 0xCF) | ((DCycle.bpwm[0] >> 2) & 0x30);
}

//-------------------------------------------------------
void main (void)
{   
  int duty = 0;
  char toggle_bit = 0;
  
  TRISA0 = 0; // Output
  TRISC2 = 0; // Set RC2/CCP1 Output

  // Setup Timer2, 1:1 Postscale, Prescaler is 1
  T2CON = 0b00000100;
    
  // PWM mode
  CCP1CON = 0b00001100;
  // 208.3 kHz PWM Frequency (Resolution 7)
  PR2 = 31;     // PWM Duty Cycle: 0-128  
  
  while (1)
  {
    for(duty=128; duty>0; duty -=2)
    {
      SetDCPWM1(duty);  // PWM duty cycle
      __delay_ms(50);
      RA0 = toggle_bit;
      toggle_bit = !toggle_bit;
    }

    for(duty=0; duty<128; duty +=2)
    {
      SetDCPWM1(duty);  // PWM duty cycle
      __delay_ms(50);
      RA0 = toggle_bit;
      toggle_bit = !toggle_bit;
    }
  }
}
