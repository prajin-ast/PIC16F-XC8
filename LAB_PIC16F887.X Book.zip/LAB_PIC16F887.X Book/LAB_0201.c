/*-------------------------------------------------------
* File    : LAB_0201.c
* Purpose : Interrupt-on-change
* Author  : Prajin Palangsantikul
-------------------------------------------------------*/
#include <xc.h>

#define _XTAL_FREQ 20000000
#pragma config FOSC = HS, WDTE = OFF, LVP = OFF

//-------------------------------------------------------
// Interrupt function all
void __interrupt() isr(void)
{
  if (RBIE && RBIF)	// RB Port change-on 
  {
    PORTA = 0x0f;
    __delay_ms(500);
    PORTB = 0;      // Write, will end the mismatch condition.
    RBIF = 0;		// Clear interrupt flag
  }
}
  
//-------------------------------------------------------
void main(void)
{
	char bit_mark = 1;
	
	ANSEL = 0x00;   // Digital I/O. Pin AN0-AN7
	ANSELH = 0x00;  // Digital I/O. Pin AN8-AN13
	TRISB = 0x01;   // RB0 as input
	TRISA = 0x00;   // PORTA as output
	
	// Configuration On-Change Interrupt
  IOCB0 = 1;      // RB0, Interrupt-on-change enabled
  RBIE = 1;       // Enables the PORTB change interrupt
  RBIF = 0;       // Clear interrupts flag bit
  GIE = 1;        // Enables all unmasked interrupts
  
	while (1)
	{
    PORTA = bit_mark;
    bit_mark = bit_mark << 1;
    if (bit_mark == 0x10)
    {
      bit_mark = 1;
    }
    __delay_ms(100);
	}	
}