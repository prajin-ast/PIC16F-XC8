/*-------------------------------------------------------
* File    : LAB_0801.c
* Purpose : ADC (AN0/RA0)
* Author  : Prajin Palangsantikul
-------------------------------------------------------*/
#include <xc.h>

#define _XTAL_FREQ 20000000
#pragma config FOSC = HS, WDTE = OFF, LVP = OFF

#include "usart.c"  // USART Library, 9600:8:N:1

//-------------------------------------------------------
void main(void)
{  
  unsigned int adc_value;
  
  INTCON = 0;   // Disable interrupts.
  init_comms(); // Set up the UART
  
  // Select RC Mode, ADC:CH0, ADON=1
  ADCON0 = 0b11000001;   
  // Result right justified, Vdd&Gnd reference source.
  ADCON1 = 0x80;
   
  while (1)
  {
    GO_nDONE = 1;     // Start conversion  
    while (GO_nDONE)  // Wait until conversion success
      ;      
    // Get ADC value
    adc_value = (ADRESH<<8) + ADRESL;
    printf("\n\rADC(AN0):%u",adc_value);
    printf("\rVolt:%.2fV",adc_value*(5.0/1023));
    __delay_ms(1000);
   }
}



