/*-------------------------------------------------------
* File    : LAB_1201.c
* Purpose : MSSP (SPI Mode)
* Author  : Prajin Palangsantikul
-------------------------------------------------------*/
#include <xc.h>

#define _XTAL_FREQ 20000000
// Configuration bits
#pragma config FOSC = HS, WDTE = OFF, LVP = OFF

#define STCP   RA0

//-------------------------------------------------------
void spi_write(unsigned char cData)
{  
  SSPBUF = cData;
  // wait for transmission complete
  while(BF);
    
  //storage register clock input
  STCP = 1;
  STCP = 0;
}

//-------------------------------------------------------
void main(void)
{
  ANSEL = 0x00;   // PORTA Digital I/O
	TRISA0 = 0;     // LatchClock pin
	TRISA1 = 0;     // Led status
	TRISC3 = 0; 	  // SCK, Set output (master mode)
  TRISC5 = 0;	    // SDO, Set output
  
  STCP = 0;       // latch pulse
  SSPEN = 0;      // Reset or reconfigure SPI mode 

  SSPEN = 1;      // Enables serial port SPI
  SSPCONbits.SSPM = 2;  // SPI Master mode, clock = FOSC/64 
         
  SMP = 0;        // Input data sampled at middle of data output time
  CKP = 0;        // Idle state for clock is a low level
  CKE = 0;        // Data transmitted on falling edge of SCK

	while (1)   // Loop forever
	{  	
  	RA1 = 0;
  	spi_write(0xAA);
  	__delay_ms(500);
  	RA1 = 1;
  	spi_write(0x55);  	
  	__delay_ms(500);
	}
}
