/*-------------------------------------------------------
* File    : LAB_0106.c
* Purpose : Input/Output port & Loop Control
* Author  : Prajin Palangsantikul
-------------------------------------------------------*/
#include <xc.h>

#define _XTAL_FREQ 20000000
#pragma config FOSC = HS, WDTE = OFF, LVP = OFF

//-------------------------------------------------------
void main(void)
{
	char mem = 0;
	
	ANSELH = 0x00;  // Digital I/O. Pin AN8-AN13
	TRISB = 0x00;   // PORTB as output
	PORTB = 0x00;   // Clear PORTB
	
	while (1)
	{
	  for (mem=0; mem<=4; mem++)
	  {
      if (mem == 0) { RB0 = 1; } 
      else if (mem == 1) { RB1 = 1; } 
      else if (mem == 2) { RB2 = 1; } 
      else if (mem == 3) { RB3 = 1; } 
      else if (mem == 4) { PORTB = 0; }
      __delay_ms(70);
	  }	
	}
}