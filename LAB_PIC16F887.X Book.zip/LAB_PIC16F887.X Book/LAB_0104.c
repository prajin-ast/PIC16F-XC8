/*-------------------------------------------------------
* File    : LAB_0104.c
* Purpose : Input/Output port & if..else statement
* Author  : Prajin Palangsantikul
-------------------------------------------------------*/
#include <xc.h>

#pragma config FOSC = HS, WDTE = OFF, LVP = OFF

//-------------------------------------------------------
void main(void)
{
  ANSEL = 0x00;   // Digital I/O. Pin AN0-AN7
  TRISA = 0x03;   // RA0/RA1 as input
  PORTA = 0x00;   // Clear PORTA
	
  while (1)
  {
  	if (RA0 == 0)
  	{
    	RA2 = 1;  // Set pin RA2 to High
    } else
    if (RA1 == 0)
    {
      RA2 = 0;  // Set pin PA2 to Low
    }
  }	
}