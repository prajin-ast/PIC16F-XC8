/*-------------------------------------------------------
* File    : LAB_0704.c
* Purpose : Comparator (C1 & SR Latch)
* Author  : Prajin Palangsantikul
-------------------------------------------------------*/
#include <xc.h>

#define _XTAL_FREQ 20000000
#pragma config FOSC = HS, WDTE = OFF, LVP = OFF

//-------------------------------------------------------
void main()
{
  TRISB0 = 0;		// Set RB0 output
  TRISA4 = 0;		// Set RA4/C1OUT output
  	
  // C1OUT is present on the RA4/C1OUT pin
  // C1VIN+ connects to C1VREF output
  // RA0/C12IN0- pin of C1 connects to C1VIN-
  // CVref > RA0/C12IN0- == C1OUT High
  // CVref < RA0/C12IN0- == C1OUT Low
  
  // Configure: Comparator (C1) module
  CM1CON0 = 0b10100100;
  // Configure: Comparator Voltage Reference 
  C1RSEL = 1;		// Set CVREF to C1
  VRCON = 0xAF;	// CVREF Value = 3.125V (CVREF=(VR<3:0>/24)*VDD)
	// Configure: SR Latch 
	SR0 = 1;      // C1OUT pin is the latch Q output
	C1SEN = 1;    // C1 comparator output sets SR latch
	PULSS = 1;    // Triggers pulse generator to set SR latch
	
	while(1);		  // Loop Nothing
}
