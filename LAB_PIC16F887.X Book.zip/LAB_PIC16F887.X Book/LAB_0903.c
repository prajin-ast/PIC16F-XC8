/*-------------------------------------------------------
* File    : LAB_0903.c
* Purpose : FLASH Memory
* Author  : Prajin Palangsantikul
-------------------------------------------------------*/
#include <xc.h>

#define _XTAL_FREQ 20000000
#pragma config FOSC = HS, WDTE = OFF, CP = OFF, LVP = OFF
	
#include "flashcopy.c"  // Flash Copy function

const unsigned char ROMSTRING[] = {1,2,3,4,5,6,7,8,9,10};

//-------------------------------------------------------
void main (void)
{   
  const unsigned char * ptr = &ROMSTRING[0];
  unsigned char data[5];
  
  flash_copy( ptr, 10, 0x810 ); // write flash
  
  data[0] = FLASH_READ(0x810);  // read flash
  data[1] = FLASH_READ(0x811);
  data[2] = FLASH_READ(0x812);
  data[3] = FLASH_READ(0x813);
  data[4] = FLASH_READ(0x814);
  
  while (1);

}

