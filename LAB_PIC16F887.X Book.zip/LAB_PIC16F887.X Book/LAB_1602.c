/*-------------------------------------------------------
* File    : LAB_1602.c
* Purpose : DHT11 Humidity & Temperature Sensor
* Author  : Prajin Palangsantikul
-------------------------------------------------------*/
#include <xc.h>
#include <stdio.h>

#define _XTAL_FREQ 20000000
#pragma config FOSC = HS, WDTE = OFF, LVP = OFF

// PIC16F887 I2C port: RC3/SCL, RC4/SDA)
#include "lcd_i2c.h"    // I2C 16x2 Serial LCD Module Display Library
#include "dht11.h"      // DHT11 Humidity&Temperature Sensor Library

//-------------------------------------------------------
void main(void)
{
  char buf[20];

  SSPMode(MASTER_MODE); // Config i2c master mode
  SSPEN = 1;            // Enables serial port i2c

  setup_timer0();
  lcd_i2c_Init();
  lcd_i2c_Write("S, Hum(%),Tmp(C)");

  while (1) // Loop forever
  {
    char chk = dht11_read();
    switch (chk)
    {
    case DHT_OK:
      lcd_i2c_Gotoxy(1,2);
      lcd_i2c_Write("OK");
      sprintf(buf,"%d.0",humidity);
      lcd_i2c_Gotoxy(4,2);
      lcd_i2c_Write(buf);
      sprintf(buf,"%d.0",temperature);
      lcd_i2c_Gotoxy(11,2);
      lcd_i2c_Write(buf);
      break;
    case DHT_ERROR_CHECKSUM:
      lcd_i2c_Gotoxy(1,2);
      lcd_i2c_Write("Checksum error");
      break;
    case DHT_ERROR_TIMEOUT:
      lcd_i2c_Gotoxy(1,2);
      lcd_i2c_Write("Time out error");
      break;
    default:
      lcd_i2c_Gotoxy(1,2);
      lcd_i2c_Write("Unknown error");
      break;
    }
    __delay_ms(1000);
    lcd_i2c_Gotoxy(1,2);
    lcd_i2c_Write("                ");  // blank character
  }
}

