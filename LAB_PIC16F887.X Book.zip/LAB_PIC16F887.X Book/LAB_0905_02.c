/*-------------------------------------------------------
* File    : LAB_0905_02.c
* Purpose : 
* Author  : Prajin Palangsantikul
-------------------------------------------------------*/
#include <xc.h>

#define _XTAL_FREQ 20000000
#pragma config FOSC = HS, WDTE = OFF, LVP = OFF

//-------------------------------------------------------
void main (void)
{   
  unsigned char value = 1;
  unsigned char address = 24;
  
  // write value to EEPROM address
  eeprom_write(address, value);

  // read from EEPROM at address
  value = eeprom_read(address);
  
  while(1);
}
