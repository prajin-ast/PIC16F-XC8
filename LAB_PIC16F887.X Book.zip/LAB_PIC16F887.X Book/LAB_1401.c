/*-------------------------------------------------------
* File    : LAB_0201.c
* Purpose : Watchdog Timer
* Author  : Prajin Palangsantikul
-------------------------------------------------------*/
#include <xc.h>

#define _XTAL_FREQ 20000000
#pragma config FOSC = HS, WDTE = OFF, LVP = OFF

//-------------------------------------------------------
void main(void)
{
  int i;
  
	ANSEL = 0x00;   // Digital I/O. Pin AN0-AN7
	TRISA = 0x00;   // PORTA as output
	
	// Configuration Watchdog Timer
	WDTCONbits.WDTPS = 2; // Period 1:128
	SWDTEN = 1;           // Enable the Watchdog Timer
	  
  for(i=0; i<10; i++)
  {
    RA0 = 1; RA1 = 0;
    __delay_ms(100);
    //CLRWDT();
    RA0 = 0; RA1 = 1;
    __delay_ms(100);
    //CLRWDT();
  }
  
  RA0 = 1; 
  RA1 = 1;
  
	while (1)   // Loop forever
	  ;
}