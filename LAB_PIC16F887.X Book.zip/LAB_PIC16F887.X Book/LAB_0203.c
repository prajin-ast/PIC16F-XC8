/*-------------------------------------------------------
* File    : LAB_0203.c
* Purpose : External Interrupt RB0/INT
* Author  : Prajin Palangsantikul
-------------------------------------------------------*/
#include <xc.h>

#define _XTAL_FREQ 20000000
#pragma config FOSC = HS, WDTE = OFF, LVP = OFF

//-------------------------------------------------------
// Interrupt function all
void __interrupt() isr(void)
{
  if (INTE && INTF)	// External interrupt
  {
    PORTA = 0x0F;
    __delay_ms(500);
    INTF = 0;		    // Clear interrupt flag
  }
}

//-------------------------------------------------------
void main(void)
{
	char bit_mark = 1;
	
	ANSEL = 0x00;   // Digital I/O. Pin AN0-AN7
	ANS12 = 0;      // RB0 as digital input
	TRISB0 = 1;     // RB0 as input
	TRISA = 0x00;   // PORTA as output
	
	// Configuration External Interrupt
	INTEDG = 0;	    // Interrupt on falling edge
  INTE = 1;       // Enables the INT external interrupt
  INTF = 0;       // Clear interrupts flag bit
  GIE = 1;        // Enables all unmasked interrupts
  
	while (1)
	{
    PORTA = bit_mark;
    bit_mark = bit_mark << 1;
    if (bit_mark == 0x10)
    {
      bit_mark = 1;
    }
    __delay_ms(100);
	}	
}