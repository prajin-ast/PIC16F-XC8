/*-------------------------------------------------------
* File    : LAB_0301.c
* Purpose : Serial I/O communications peripheral
* Author  : Prajin Palangsantikul
* Ref.    : HI-TECH C (usart.c)
-------------------------------------------------------*/
#include <xc.h>

#pragma config FOSC = HS, WDTE = OFF, LVP = OFF

#include <stdio.h>
#include "usart.c"  // USART Library, 9600:8:N:1

//-------------------------------------------------------
void main(void)
{
  char ch;
  
  INTCON = 0;   // Disable interrupts.
  init_comms(); // Set up the UART
  
  printf("\n\rSerial Communication port (RS232)");
  printf("\n\rPress a anykey");
  
  while (1)
  {    
    ch = _getch();	// Read a data 
    printf("\n\rYour input: ");
    _putch(ch);
  }	
}