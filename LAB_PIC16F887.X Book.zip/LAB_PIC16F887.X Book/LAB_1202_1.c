/*-------------------------------------------------------
* File    : LAB_1202.c
* Purpose : MSSP (I2C Mode)
* Author  : Prajin Palangsantikul
-------------------------------------------------------*/
#include <xc.h>

#define _XTAL_FREQ 20000000
// Configuration bits
#pragma config FOSC = HS, WDTE = OFF, LVP = OFF

#define EEPROM_Addr   0xA0  // Device address '10100000'
#include "i2c.h"            // I2C Library
#include "usart.c"          // USART Library, 9600:8:N:1

//-------------------------------------------------------
void i2c_eeprom_write(void)
{
  int i;
  unsigned char data;
  
  printf("\n\rWrite dat to EEPROM: ");
  if(i2c_WriteTo(EEPROM_Addr))
  {
    printf("\n\raddress is not acknowledged");
    return;
  }
  i2c_PutByte(0x00);
  i2c_PutByte(0x00);
  for(i=0; i<26; i++)
	{
    data = 'A' + i;
    i2c_PutByte(data);	  // Send data
    printf("%c, ",data);
  }
  i2c_Stop();
}

//-------------------------------------------------------
void i2c_eeprom_read(void)
{
  int i;
  unsigned char data;
  
  printf("\n\rRead data from EEPROM: ");

  if(i2c_WriteTo(EEPROM_Addr))
  {
    printf("\n\raddress is not acknowledged");
    return;
  }
  i2c_PutByte(0x00);
  i2c_PutByte(0x00);
  i2c_ReadFrom(EEPROM_Addr);
  for(i=0; i<26; i++)
  {
    data = i2c_GetByte(I2C_MORE);	  // Read data
    printf("%c, ",data);
  }
  i2c_Stop();
}

//-------------------------------------------------------
void main(void)
{
  INTCON = 0;   // Disable interrupts.	
  init_comms(); // Set up the UART

  SSPMode(MASTER_MODE); // Config i2c master mode
  SSPEN = 1;            // Enables serial port i2c  
  //CKP = 1;
  //SSPCON=0b00101000;
  //SSPADD=0x05;

  i2c_eeprom_write();   // eeprom write data	
  i2c_eeprom_read();

	while (1)   // Loop forever
  ;
}
