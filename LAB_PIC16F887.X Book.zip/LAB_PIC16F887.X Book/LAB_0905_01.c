/*-------------------------------------------------------
* File    : LAB_0905_01.c
* Purpose : 
* Author  : Prajin Palangsantikul
-------------------------------------------------------*/
#include <xc.h>

#define _XTAL_FREQ  20000000    // 20MHz
#pragma config FOSC = HS, WDTE = OFF, LVP = OFF

__EEPROM_DATA(0, 1, 2, 3, 4, 5, 6, 7);

//-------------------------------------------------------
void main (void)
{  
  while(1);
}
