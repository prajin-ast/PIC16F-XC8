/*-------------------------------------------------------
* File    : LAB_0905_03.c
* Purpose : 
* Author  : Prajin Palangsantikul
-------------------------------------------------------*/
#include <xc.h>

#define _XTAL_FREQ 20000000
#pragma config FOSC = HS, WDTE = OFF, LVP = OFF

//-------------------------------------------------------
void main (void)
{   
  unsigned char value = 1;
  unsigned char address = 0;

  // Initiate writing value to address
  EEPROM_WRITE(address,value);
  
  // wait for end-of-write before EEPROM_READ
  while(WR)
    continue; 
    
  // read from EEPROM at address
  value = EEPROM_READ(address);
  
  while(1);
}
