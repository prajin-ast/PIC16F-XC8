/*-------------------------------------------------------
* File    : LAB_0702.c
* Purpose : Comparator (C2 with Timer1 gate)
* Author  : Prajin Palangsantikul
-------------------------------------------------------*/
#include <xc.h>

#define _XTAL_FREQ 20000000
#pragma config FOSC = HS, WDTE = OFF, LVP = OFF

//-------------------------------------------------------
void __interrupt() isr(void)
{
  static unsigned char tick = 0;
  static bit toggle = 0;
  
  if (TMR1IE && TMR1IF)	// Timer1 Overflow Interrupt Flag
  {
    if (tick++ > 9) // 1s
    {
      tick = 0;
      toggle = !toggle;      
      if (toggle) 
        RB0 = 1;
      else
        RB0 = 0;      
    }
    TMR1IF = 0; // Clear interrupt flag
  }
}

//-------------------------------------------------------
void main()
{
  TRISB0 = 0;  // Set RB0 output
  TRISA5 = 0;	 // Set RA5/C2OUT output
  RB0 = 0;     // Celar RB0
  	
  // Configure: Comparator C2 module
  C2ON = 1;    // Enable Comparator C2
  C2OE = 1;    // C2OUT is present on the C2OUT pin
  C2POL = 0;   // C2OUT logic is not inverted
  C2R = 0;     // RA2/C2VIN+ connects to C2IN+ pin
  C2CH0 = 0;   // RA0/C12IN0- pin of C2 connects to C2VIN-
  C2CH1 = 0;  
	
	T1GSS = 0;   // Timer1 gate source is SYNCC2OUT

  // Setup Timer1 (Timer mode)
  TMR1GE = 1;  // Use the Timer1 gate control
  T1GINV = 1;  // Timer1 gate is active-high
  T1CKPS0 = 1; // Timer1 Input Clock Prescale Select (1:8)
  T1CKPS1 = 1; //
  TMR1CS = 0;  // Internal clock (FOSC/4)
  TMR1ON = 1;  // Enable Timer1 
  TMR1 = 0;    // Clear Timer1
	
  // Configure: Comparator Interrupt 
  TMR1IE = 1;  // Enables the Timer1 interrupt
  TMR1IF = 0;  // Clear Timer1 interrupt flag
  PEIE = 1;    // Peripheral interrupt enable	
  GIE = 1;     // Enable Global interrupt
	
	while (1);
}
  