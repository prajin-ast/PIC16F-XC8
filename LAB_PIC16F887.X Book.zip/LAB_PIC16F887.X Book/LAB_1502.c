/*-------------------------------------------------------
* File    : LAB_1502.c
* Purpose : Dual-axis XY Joystick Module and PWM Control
* Author  : Prajin Palangsantikul
-------------------------------------------------------*/
#include <xc.h>

#define _XTAL_FREQ 20000000
#pragma config FOSC = HS, WDTE = OFF, LVP = OFF

#include "usart.c"  // USART Library, 9600:8:N:1

// Union used to hold the 10-bit duty cycle */
union PWMDC
{
  unsigned int lpwm;
  char bpwm[2];
};

//-------------------------------------------------------
void SetDCPWM1(unsigned int dutycycle)
{
  union PWMDC DCycle;

  // Save the dutycycle value in the union
  DCycle.lpwm = dutycycle << 6;
  // Write the high byte into CCPR1L
  CCPR1L = DCycle.bpwm[1];
  // Write the low byte into CCP1CON5:4
  CCP1CON = (CCP1CON & 0xCF) | ((DCycle.bpwm[0] >> 2) & 0x30);
}

//-------------------------------------------------------
unsigned int ADC_Read(unsigned char adc_ch)
{
  ADCON0bits.CHS = adc_ch;
  __delay_us(20);   // Wait for mux
  GO_nDONE = 1;     // Start conversion
  while(GO_nDONE)   // Wait until conversion success
    ;
  // Get ADC value
  return ((ADRESH<<8) + ADRESL);
}

//-------------------------------------------------------
// Ref: arduino.cc
long map(long x, long in_min, long in_max, long out_min, long out_max)
{
  return (x - in_min) * (out_max - out_min) / (in_max - in_min) + out_min;
}

//-------------------------------------------------------
void main(void)
{
  int duty = 0;

  INTCON = 0;   // Disable interrupts.
  init_comms(); // Set up the UART

  // Select RC Mode, ADC_CH, ADON=1
  ADCON0 = 0b11000001;
  // Result right justified, Vdd&Gnd reference source.
  ADCON1 = 0x80;

  TRISC2 = 0;   // Set RC2/CCP1 Output
  // Setup Timer2, 1:1 Postscale, Prescaler is 1
  T2CON = 0b00000100;
  // PWM mode
  CCP1CON = 0b00001100;
  // 208.3 kHz PWM Frequency (Resolution 7)
  PR2 = 31;     // PWM Duty Cycle: 0-128

  TRISB0 = 1;   // Set RB0 input
  ANS12 = 0;    // Off Analog (AN12)
  WPUB0 = 1;	// RB0 pull-up enable
  nRBPU = 0;    // Individual pull-ups
  TRISB1 = 0;   // Set RB1 output
  TRISB2 = 0;   // Set RB2 output

  while (1)
  {
    if (RB0 == 0)
    {
      printf("\n\rSW Press");
    } else
    {
      printf("\n\rADC(AN0): %u", ADC_Read(0));
      printf("\n\rADC(AN1): %u", ADC_Read(1));
      
      // Map an analog value to 7 bits (0 to 128)
      duty = map(ADC_Read(0), 0, 1023, 0, 128);
      SetDCPWM1(duty);  // PWM duty cycle
      if (ADC_Read(1) < 10)
      {
        RB1 = 1;
      } else
      if (ADC_Read(1) >1000)
      {
        RB1 = 0;
      }
    }
    __delay_ms(500);
  }
}
