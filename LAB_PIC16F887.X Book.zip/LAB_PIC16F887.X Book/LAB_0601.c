/*-------------------------------------------------------
* File    : LAB_0601.c
* Purpose : Timer2 (Timer mode with Postscaler)
* Author  : Prajin Palangsantikul
-------------------------------------------------------*/
#include <xc.h>

#define _XTAL_FREQ 20000000
#pragma config FOSC = HS, WDTE = OFF, LVP = OFF

unsigned char tick = 0;

//-------------------------------------------------------
// Interrupt function all
void __interrupt() isr(void)
{
  if (TMR2IE && TMR2IF)	// Timer2 Overflow Interrupt Flag
  {
    if (tick++ > 76) // 1s
    {
      PORTD = 0x0F;
      __delay_ms(1000);
      tick = 0;
    }
    TMR2IF = 0;  // Clear interrupt flag
  }
}

//-------------------------------------------------------
void main(void)
{
	TRISD = 0;  // PORTB as output
  PORTD = 0;  // Clear port
 
  // Setup Timer2 (Timer mode)
  T2CONbits.TOUTPS = 0b1111;  // Timer2 Output Postscaler Select
  T2CONbits.T2CKPS = 0b11;    // Timer2 Clock Prescale Select
  TMR2ON = 1;   // Enables Timer1
  TMR2 = 0;     // Clear Timer1
  
  // Configuration Timer1 Interrupt
  TMR2IE = 1;   // Enables the Timer0 interrupt
  TMR2IF = 0;   // Clear Timer1 interrupt flag
  PEIE = 1;	    // Enables all unmasked peripheral interrupts
  GIE = 1;	    // Enables all unmasked interrupts
	  	  
	while (1)
	{
    RD0 = 0;  RD1 = 1;
    RD2 = 0;  RD3 = 1;
    __delay_ms(100);
    RD0 = 1;  RD1 = 0;
    RD2 = 1;  RD3 = 0;    
    __delay_ms(100);    
	}	
}
