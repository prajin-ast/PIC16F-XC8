/*-------------------------------------------------------
* File    : dht11.h
* Purpose : DHT11 Temperature & Humidity Sensor library
* Author  : Prajin Palangsantikul
* Ref     : http://playground.arduino.cc/Main/DHT11Lib
-------------------------------------------------------*/

#include <xc.h>
#define _XTAL_FREQ 20000000

#define DHT_OK                0
#define DHT_ERROR_CHECKSUM   -1
#define DHT_ERROR_TIMEOUT    -2

#define DHT11_IO                TRISD0
#define DHT11_PIN               RD0

int humidity;
int temperature;

void setup_timer0();
int dht11_read();

// Return values:
// DHT_OK
// DHT_ERROR_CHECKSUM
// DHT_ERROR_TIMEOUT
int dht11_read()
{
        // BUFFER TO RECEIVE
        uint8_t bits[5];
        uint8_t cnt = 7;
        uint8_t idx = 0;

        // EMPTY BUFFER
        for (int i=0; i< 5; i++) bits[i] = 0;

        // REQUEST SAMPLE
        DHT11_IO = 0;       // set output
        DHT11_PIN = 0;      // out low
        __delay_ms(18);     // least 18ms
        DHT11_PIN = 1;      // out high
        __delay_us(40);     // response 20-40us
        
        DHT11_IO = 1;       // set input
        
        // ACKNOWLEDGE or TIMEOUT
        unsigned int loopCnt = 10000;
        while(DHT11_PIN == 0)
                if (loopCnt-- == 0) return DHT_ERROR_TIMEOUT;

        loopCnt = 10000;
        while(DHT11_PIN == 1)
                if (loopCnt-- == 0) return DHT_ERROR_TIMEOUT;

        // READ OUTPUT - 40 BITS => 5 BYTES or TIMEOUT
        for (int i=0; i<40; i++)
        {
                TMR0 = 0;   // Start count
                loopCnt = 10000;
                while(DHT11_PIN == 0)
                    if (loopCnt-- == 0) return DHT_ERROR_TIMEOUT;

                loopCnt = 10000;
                while(DHT11_PIN == 1)
                    if (loopCnt-- == 0) return DHT_ERROR_TIMEOUT;

                // 11 * 6.4us = 70.4us
                if (TMR0 > 11)  bits[idx] |= (1 << cnt);
                if (cnt == 0)   // next byte?
                {
                    cnt = 7;    // restart at MSB
                    idx++;      // next byte!
                }
                else cnt--;
        }

        // WRITE TO RIGHT VARS
        // as bits[1] and bits[3] are allways zero they are omitted in formulas.
        humidity = bits[0];
        temperature = bits[2];

        uint8_t sum = bits[0] + bits[2];  

        if (bits[4] != sum) return DHT_ERROR_CHECKSUM;
        return DHT_OK;
}

//-------------------------------------------------------
void setup_timer0()
{
    // Setup Timer0 (Timer mode)
    T0CS = 0;   // Internal instruction cycle clock (FOSC/4)
    PSA = 0;    // Prescaler is assigned to the Timer0
    // t = 1/(FOSC/4 x Prescaler)
    //   = 1/[20Mhz/(4x32)]
    //   = 128/20 us
    //   = 6.4 us (1 tick)
    PS2 = 1;    // Prescaler Rate Select PS0-PS2(1:32)
    PS1 = 0;    //
    PS0 = 0;    //
    TMR0 = 0;   // Start count
}

