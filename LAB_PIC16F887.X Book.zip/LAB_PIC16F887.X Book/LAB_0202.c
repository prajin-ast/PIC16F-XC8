/*-------------------------------------------------------
* File    : LAB_0202.c
* Purpose : Interrupt-on-change
* Author  : Prajin Palangsantikul
-------------------------------------------------------*/
#include <xc.h>

#define _XTAL_FREQ 20000000
#pragma config FOSC = HS, WDTE = OFF, LVP = OFF

char ship_flag = 0;

//-------------------------------------------------------
// Interrupt function all
void __interrupt() isr(void)
{
  if (RBIE && RBIF)	// RB Port change-on 
  {
    if (RB0 == 0)
    {
      ship_flag = 0;
    }
    if (RB1 == 0)
    {
      ship_flag = 1;
    }
    PORTB = 0;	// Wirte, will end the mismatch condition.
    RBIF = 0;		// Clear interrupt flag
  }
}

//-------------------------------------------------------
void main(void)
{
	char bit_mark = 1;
	
	ANSEL = 0x00;   // Digital I/O. Pin AN0-AN7
	ANSELH = 0x00;  // Digital I/O. Pin AN8-AN13
	TRISB = 0x03;   // RB0,RB1 as input
	TRISA = 0x00;   // PORTA as output
	
	// Configuration On-Change Interrupt
  IOCB0 = 1;      // RB0, Interrupt-on-change enabled
  IOCB1 = 1;      // RB1, Interrupt-on-change enabled
  RBIE = 1;       // Enables the PORTB change interrupt
  RBIF = 0;       // Clear interrupts flag bit
  GIE = 1;        // Enables all unmasked interrupts
  
	while (1)
	{
  	PORTA = bit_mark;
  	if (ship_flag == 0)
  	{
    	bit_mark = bit_mark << 1;
      if (bit_mark == 0x10)
  	  {
    	  bit_mark = 0x01;
  	  }
  	} else {
  	  bit_mark = bit_mark >> 1;
  	  if (bit_mark == 0)
  	  {
    	  bit_mark = 0x10;
  	  }
  	}
    __delay_ms(100);
	}	
}