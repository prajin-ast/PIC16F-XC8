/*-------------------------------------------------------
* File    : LAB_0602.c
* Purpose : Timer2 (Timer mode with PR2)
* Author  : Prajin Palangsantikul
-------------------------------------------------------*/
#include <xc.h>

#define _XTAL_FREQ 20000000
#pragma config FOSC = HS, WDTE = OFF, LVP = OFF

bit toggle = 0;

//-------------------------------------------------------
// Interrupt function all
void __interrupt() isr(void)
{
  static unsigned char tick = 0;
  
  if (TMR2IE && TMR2IF)	// Timer2 Overflow Interrupt Flag
  {
    if (tick++ > 200) // 100ms
    {
      toggle = !toggle;
      tick = 0;
    }
    TMR2IF = 0;  // Clear interrupt flag
  }
}

//-------------------------------------------------------
void main(void)
{
	TRISD = 0;  // PORTB as output
  PORTD = 0;  // Clear port
 
  // Setup Timer2 (Timer mode)
  T2CONbits.TOUTPS = 0b1001;  // Timer2 Output Postscaler Select
  T2CONbits.T2CKPS = 0;       // Timer2 Clock Prescale Select
  TMR2ON = 1;   // Enables Timer1
  PR2 = 250;    // period register
  TMR2 = 0;     // Clear Timer1
  
  // Configuration Timer1 Interrupt
  TMR2IE = 1;   // Enables the Timer0 interrupt
  TMR2IF = 0;   // Clear Timer1 interrupt flag
  PEIE = 1;	    // Enables all unmasked peripheral interrupts
  GIE = 1;	    // Enables all unmasked interrupts
	  	  
	while (1)
	{
    if (toggle)
    {
      RD0 = 1;  RD1 = 1;
      RD2 = 0;  RD3 = 0;
    } else {
      RD0 = 0;  RD1 = 0;
      RD2 = 1;  RD3 = 1;
    }
	}	
}
