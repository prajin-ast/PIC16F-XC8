/*-------------------------------------------------------
* File    : LAB_0802.c
* Purpose : ADC (Multi Channel)
* Author  : Prajin Palangsantikul
-------------------------------------------------------*/
#include <xc.h>

#define _XTAL_FREQ 20000000
#pragma config FOSC = HS, WDTE = OFF, LVP = OFF

#include "usart.c"  // USART Library, 9600:8:N:1

//-------------------------------------------------------
unsigned int ADC_Read(unsigned char adc_ch)
{  
  ADCON0bits.CHS = adc_ch;
   
  __delay_us(20);   // Wait for mux
    
  GO_nDONE = 1;     // Start conversion  
  while(GO_nDONE)   // Wait until conversion success
    ;  
	
  // Get ADC value
  return ((ADRESH<<8) + ADRESL);
}

//-------------------------------------------------------
void main(void)
{  
  unsigned int adc_value;
  
  INTCON = 0;   // Disable interrupts.
  init_comms(); // Set up the UART

  // Select RC Mode, ADC_CH, ADON=1
  ADCON0 = 0b11000001;
  
  // Result right justified, Vdd&Gnd reference source.
  ADCON1 = 0x80;

  while (1)
  {
    adc_value = ADC_Read(0);
    printf("\n\rADC(AN0): %u",adc_value);
    adc_value = ADC_Read(1);
    printf("\n\rADC(AN1): %u",adc_value);
    adc_value = ADC_Read(2);
    printf("\n\rADC(AN2): %u",adc_value);
    adc_value = ADC_Read(3);
    printf("\n\rADC(AN3): %u",adc_value);
    __delay_ms(1000);
  }
}



