/*-------------------------------------------------------
* File    : LAB_1501.c
* Purpose : Dual-axis XY Joystick Module
* Author  : Prajin Palangsantikul
-------------------------------------------------------*/
#include <xc.h>

#define _XTAL_FREQ 20000000
#pragma config FOSC = HS, WDTE = OFF, LVP = OFF

#include "usart.c"  // USART Library, 9600:8:N:1

//-------------------------------------------------------
unsigned int ADC_Read(unsigned char adc_ch)
{
  ADCON0bits.CHS = adc_ch;
  __delay_us(20);   // Wait for mux
  GO_nDONE = 1;     // Start conversion
  while(GO_nDONE)   // Wait until conversion success
    ;
  // Get ADC value
  return ((ADRESH<<8) + ADRESL);
}

//-------------------------------------------------------
void main(void)
{
  INTCON = 0;   // Disable interrupts.
  init_comms(); // Set up the UART

  // Select RC Mode, ADC_CH, ADON=1
  ADCON0 = 0b11000001;
  // Result right justified, Vdd&Gnd reference source.
  ADCON1 = 0x80;

  TRISB0 = 1;   // Set RB0 input
  ANS12 = 0;    // Off Analog (AN12)
  WPUB0 = 1;	// RB0 pull-up enable
  nRBPU = 0;    // Individual pull-ups

  while (1)
  {
    if (RB0 == 0)
    {
      printf("\n\rSW Press");
    } else
    {
      printf("\n\rADC(AN0): %u",ADC_Read(0));
      printf("\n\rADC(AN1): %u",ADC_Read(1));
    }
    __delay_ms(500);
  }
}
