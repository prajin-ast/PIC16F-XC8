/*-------------------------------------------------------
* File    : LAB_0107.c
* Purpose : Input/Output port & Individual pull-ups
* Author  : Prajin Palangsantikul
-------------------------------------------------------*/
#include <xc.h>

#define _XTAL_FREQ 20000000
#pragma config FOSC = HS, WDTE = OFF, LVP = OFF

//-------------------------------------------------------
void main(void)
{
	ANSELH = 0x00;  // Digital I/O. Pin AN8-AN13
	TRISB = 0x03;   // RB0,RB1 as input
	PORTB = 0x00;   // Clear PORTB
  WPUB0 = 1;	    // RB0 pull-up enable
	WPUB1 = 1;      // RB1 pull-up enable
	nRBPU = 0;      // Individual pull-ups

	while (1)
	{
    if (RB0 == 0)
    {
      RB2 = 1;
      RB3 = 0;
    } else
    if (RB1 == 0)
    {
      RB2 = 0;
      RB3 = 1;
    }
	}
}