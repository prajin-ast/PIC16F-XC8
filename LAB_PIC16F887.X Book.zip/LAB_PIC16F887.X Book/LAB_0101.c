/*-------------------------------------------------------
* File    : LAB_0101.c
* Purpose : Output port
* Author  : Prajin Palangsantikul
-------------------------------------------------------*/
#include <xc.h>

// Configuration bits
#pragma config FOSC = HS, WDTE = OFF, LVP = OFF

//-------------------------------------------------------
void main(void)
{
  ANSEL = 0x00;   // PORTA Digital I/O
	TRISA = 0x00;   // PORTA pin configured as an output
	PORTA = 0x00;   // Clear PORTA
	RA0 = 1;            // Set pin RA0 to High
	PORTAbits.RA1 = 1;  // Set pin RA1 to High
	
	while (1);      // Loop forever
}
