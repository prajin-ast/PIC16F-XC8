/*-------------------------------------------------------
* File    : LAB_0103.c
* Purpose : Input/Output port
* Author  : Prajin Palangsantikul
-------------------------------------------------------*/
#include <xc.h>

#pragma config FOSC = HS, WDTE = OFF, LVP = OFF

//-------------------------------------------------------
void main(void)
{
  ANSEL = 0x00;   // Digital I/O. Pin AN0-AN7
  TRISA = 0x01;   // RA0 as input
  PORTA = 0x00;   // Clear PORTA
	
  while (1)
  {
    if (RA0 == 0)
    {
      RA1 = 1;  // Set pin PORTA.1 to High
    } else
    {
      RA1 = 0;  // Set pin PORTA.1 to Low
    }
  }	
}
