/*-------------------------------------------------------
* File    : LAB_0501.c
* Purpose : Timer1 (Timer mode)
* Author  : Prajin Palangsantikul
-------------------------------------------------------*/
#include <xc.h>

#define _XTAL_FREQ 20000000
#pragma config FOSC = HS, WDTE = OFF, LVP = OFF

bit sw = 0;

//-------------------------------------------------------
// Interrupt function all
void __interrupt() isr(void)
{
  static unsigned char tick = 0;
  
  if (TMR1IE && TMR1IF)	// Timer1 Overflow Interrupt Flag
  {
    if (tick++ > 9) // 1s
    {
      sw = !sw;
      if (sw == 0)
      {
        PORTD = 0x01; // Set RD0
      } else {
        PORTD = 0x04; // Set RD2
      }
      tick = 0;
    }
    TMR1IF = 0; // Clear interrupt flag
  }
}

//-------------------------------------------------------
void main(void)
{
  unsigned int cnt_ms = 0;
  
	TRISD = 0;    // PORTB as output
  PORTD = 0x01; // Set RD0
 
  // Setup Timer1 (Timer mode)
  T1CKPS0 = 1;  // Timer1 Input Clock Prescale Select (1:8)
  T1CKPS1 = 1;  //
  TMR1CS = 0;   // Internal clock (FOSC/4)
  TMR1ON = 1;   // Enable Timer1 
  TMR1 = 0;     // Clear Timer1
  
  // Configuration Timer1 Interrupt
  TMR1IE = 1;   // Enables the Timer0 interrupt
  TMR1IF = 0;   // Clear Timer1 interrupt flag
  PEIE = 1;     // Enables all unmasked peripheral interrupts
  GIE = 1;      // Enables all unmasked interrupts

	while (1)
	{
    if (cnt_ms++ > 100)
    {
      if (sw == 0)
      {
        RD0 = !RD0;
        RD1 = !RD1;
      } else {
        RD2 = !RD2;
        RD3 = !RD3;
      }
      cnt_ms = 0;
    } else {
      __delay_ms(1);
    }
  }
}
