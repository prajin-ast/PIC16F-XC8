/*-------------------------------------------------------
* File    : LAB_0703.c
* Purpose : Comparator (C1 with CVREF)
* Author  : Prajin Palangsantikul
-------------------------------------------------------*/
#include <xc.h>

#define _XTAL_FREQ 20000000
#pragma config FOSC = HS, WDTE = OFF, LVP = OFF

//-------------------------------------------------------
void __interrupt() isr(void)
{
  if (C1IE && C1IF)   // Check C1 Interrupt Flag
  {
    RB0 = 1;          // High RB0
    __delay_ms(250);  // Delay 0.25s
    RB0 = 0;		      // Low RB0
    C1IF = 0;		      // Clear C1 Interrupt Flag
  }
}

//-------------------------------------------------------
void main()
{
  TRISB0 = 0;   // Set RB0 output
  TRISA4 = 0;   // Set RA4/C1OUT output
  	
  // Configure: Comparator C1 module
  C1ON = 1;     // Enable Comparator C1
  C1OE = 1;     // C1OUT is present on the C1OUT pin
  C1POL = 0;    // C1OUT logic is not inverted
  C1R = 1;      // C1VIN+ connects to C1VREF output
  C1CH0 = 0;    // RA0/C12IN0- pin of C1 connects to C1VIN-
  C1CH1 = 0;
  C1RSEL = 1;   // Set CVREF by program
  VRCON = 0xAF; // Config. 3.125V reference(CVREF = (VR<3:0>/24)*VDD)
	
  // Configure: Comparator Interrupt 
  C1IF = 0;   // Ensure clear interrupt flag
  C1IE = 1;   // Enable C1 interrupt  
  PEIE = 1;   // Peripheral interrupt enable	
  GIE = 1;    // Enable Global interrupt
	
	while (1);
}
