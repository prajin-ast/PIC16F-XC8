/*-------------------------------------------------------
* File    : LAB_1302.c
* Purpose : LED 7-Segments
* Author  : Prajin Palangsantikul
-------------------------------------------------------*/
#include <xc.h>

#define _XTAL_FREQ 20000000
// Configuration bits
#pragma config FOSC = HS, WDTE = OFF, LVP = OFF

// Global Variables
// 0x77, 0x39, 0x79 => A,C,E
// 0x71, 0x74, 0x5C => F,H,O
// 0x73, 0x6D, 0x78 => P,S,T
const char LED_CHR[17] 
  = { 0x77, 0x73, 0x73,         // APP
      0x6D, 0x5C, 0x71, 0x78,   // SOFT
      0x78, 0x79, 0x39, 0x74,   // TECH
      0x00, 0x00, 0x00,         // bank, bank, bank
      0x77,0x6D,0x78            // AST
    };

const char LED_NUM[17] 
  = { 0x3F, 0x06, 0x5B, 0x4F, 0x66,  //0,1,2,3,4
      0x6D, 0x7D, 0x07, 0x7F, 0x6F,  //5,6,7,8,9
      0x77, 0x7C, 0x39, 0x5E, 0x79,  //A,b,C,d,E
      0x71, 0x80,                    //F,.
    };  

// Dispaly Digit1/2/3
void dsp_digit1(char n) 
{
  PORTA = 0x06;
  PORTD = n;
  __delay_ms(1);
}

void dsp_digit2(char n) 
{
  PORTA = 0x05;
  PORTD = n;
  __delay_ms(1);  
}

void dsp_digit3(char n) 
{
  PORTA = 0x03;
  PORTD = n;
  __delay_ms(1);
}

//-------------------------------------------------------
void main(void)
{
  unsigned int i,j;
  unsigned int cc;

  ANSEL = 0x00;   // Digital I/O. Pin AN0-AN7
  TRISA = 0x00;   // PORTA output
  TRISD = 0x00;   // PORTD output

  while(1) 
  {
    // Display APPSOFTTECH
    for(i=0; i<14; i++) 
    {
      for(j=0; j<200; j++) 
      {    // for display loop
        dsp_digit1(LED_CHR[i]);
        if(i>0) dsp_digit2(LED_CHR[i-1]);
        if(i>1) dsp_digit3(LED_CHR[i-2]);
      }
      // Display AST
      if(i==13) 
      {
        for(j=0; j<5; j++) 
        {
          for(cc=0; cc<200; cc++) 
          {
            dsp_digit1(LED_CHR[16]|LED_NUM[16]);  // Or dot dp
            dsp_digit2(LED_CHR[15]);
            dsp_digit3(LED_CHR[14]);
          }
          RA2 = 1;          // disable digit3
          __delay_ms(500);    // delay
        }
      }
    }
    // Display Countdown number 333 to 0 
    for(i=333; i>0; i--) 
    {
      for(j=0; j<10; j++)
      {    // for display loop
        dsp_digit1(LED_NUM[((i%100)%10)]);      
        dsp_digit2(LED_NUM[((i%100)/10)]);
        dsp_digit3(LED_NUM[(i/100)]);
      }    
    }      
  }
}
                      