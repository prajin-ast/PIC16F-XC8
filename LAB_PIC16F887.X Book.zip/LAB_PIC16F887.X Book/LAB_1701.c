/*-------------------------------------------------------
* File    : LAB_1701.c
* Purpose : Standard Servo Motor
* Author  : Prajin Palangsantikul
-------------------------------------------------------*/
#include <xc.h>

#define _XTAL_FREQ 20000000
#pragma config FOSC = HS, WDTE = OFF, LVP = OFF

//-------------------------------------------------------
void servo_center(long pulse)
{
  while(pulse--)
  {
    RA0 = 1;  __delay_us(1500); // Center
    RA0 = 0;  __delay_ms(20);
  }
}

//-------------------------------------------------------
void servo_left(long pulse)
{
  while(pulse--)
  {
    RA0 = 1;  __delay_us(2300); // Counter-Clockwise
    RA0 = 0;  __delay_ms(20);
  }
}

//-------------------------------------------------------
void servo_right(long pulse)
{
  while(pulse--)
  {
    RA0 = 1;  __delay_us(700);  // Clockwise
    RA0 = 0;  __delay_ms(20);
  }
}

//-------------------------------------------------------
void wait_s(long tm)
{
  while(tm--)
  {
    __delay_ms(1000); // 1s
  }
}

//-------------------------------------------------------
void main(void)
{
  TRISA0 = 0; // Output
  servo_center(100);
  
  while(1)
  {
    servo_left(100);
    wait_s(1);
    servo_right(100);
    wait_s(1);
  }
}
