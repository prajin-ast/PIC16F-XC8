/*-------------------------------------------------------
* File    : LAB_0102.c
* Purpose : Output port & delay function
* Author  : Prajin Palangsantikul
-------------------------------------------------------*/
#include <xc.h>

// This definition is required to calibrate __delay_us() 
// and __delay_ms()
#define _XTAL_FREQ 20000000

// Configuration bits
#pragma config FOSC = HS, WDTE = OFF, LVP = OFF

//-------------------------------------------------------
void main(void)
{
  ANSEL = 0x00;   // PORTA Digital I/O
  TRISA = 0x00;   // PORTA pin configured as an output
  PORTA = 0x00;   // Clear PORTA
	
  while (1)
  {
    RA0 = 1;  // Set pin PORTA.0 to High
    RA1 = 0;  // Set pin PORTA.1 to Low
    __delay_ms(100);
    RA0 = 0;  // Set pin PORTA.0 to Low
    RA1 = 1;  // Set pin PORTA.1 to High
    __delay_ms(100);    
  }	
}
