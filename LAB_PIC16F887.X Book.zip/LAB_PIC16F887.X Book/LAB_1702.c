/*-------------------------------------------------------
* File    : LAB_1702.c
* Purpose : DC Motor
* Author  : Prajin Palangsantikul
-------------------------------------------------------*/
#include <xc.h>

#define _XTAL_FREQ 20000000
#pragma config FOSC = HS, WDTE = OFF, LVP = OFF

#include "driver_pwm.c"

#define max_power       1023

#define MOTOR_L_A       RD0       // 1INa
#define MOTOR_L_B       RD1       // 1INb
#define MOTOR_L_PWM     RC1       // 1PWM
#define MOTOR_R_A       RD2       // 2INa
#define MOTOR_R_B       RD3       // 2INb
#define MOTOR_R_PWM     RC2       // 2PWM

//-------------------------------------------------------
void motor_drive(int power1, int power2)
{
  // motorA
  if (power1 > 0)
  {
    MOTOR_L_A = 1;  MOTOR_L_B = 0;
  } else if (power1 < 0)
  {
    power1 = -power1;
    MOTOR_L_A = 0;  MOTOR_L_B = 1;
  } else if (power1 == 0)
  {
    MOTOR_L_B = 0;  MOTOR_L_A = 0;
  }
  // motorB
  if (power2 > 0)
  {
    MOTOR_R_A = 1;  MOTOR_R_B = 0;
  } else if (power2 < 0)
  {
    power2 = -power2;
    MOTOR_R_A = 0;  MOTOR_R_B = 1;
  } else if (power2 == 0)
  {
    MOTOR_R_B = 0;  MOTOR_R_A = 0;
  }

  if (power1 > max_power) power1 = max_power;
  if (power2 > max_power) power2 = max_power;

  SetDCPWM1(power1);    // MotorA PWM
  SetDCPWM2(power2);    // MotorB PWM
}

//-------------------------------------------------------
void wait_s(long tm)
{
  while(tm--)
  {
    __delay_ms(1000); // 1s
  }
}

//-------------------------------------------------------
void main(void)
{
  int power = 100;

  TRISD0 = 0;
  TRISD1 = 0;
  TRISD2 = 0;
  TRISD3 = 0;

  ConfigPWM();
  
  while(1)
  {
    motor_drive(power, power);
    wait_s(2);
    motor_drive(0, 0);
    wait_s(1);
    motor_drive(-power, power);
    wait_s(2);
    motor_drive(0, 0);
    wait_s(1);
    motor_drive(power, -power);
    wait_s(2);
    power + = 100;
    if (power > 1023) power = 0;
  }
}

