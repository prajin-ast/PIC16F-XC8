/*-------------------------------------------------------
* File    : driver_pwm.c
* Purpose : CCP1 (PWM)
* Author  : Prajin Palangsantikul
-------------------------------------------------------*/
#include <xc.h>

// Union used to hold the 10-bit duty cycle */
union PWMDC
{
  unsigned int lpwm;
  char bpwm[2];
};

void ConfigPWM(void);
void SetDCPWM1(unsigned int dutycycle);
void SetDCPWM2(unsigned int dutycycle);

//-------------------------------------------------------
void ConfigPWM(void)
{
  // Set RC2/CCP1, RC1/CCP2 Output
  TRISC2 = 0;
  TRISC1 = 0;
  // Setup Timer2, 1:1 Postscale, Prescaler is 1
  T2CON = 0b00000100;
  // PWM mode
  CCP1CON = 0b00001100;
  CCP2CON = 0b00001100;
  // 19.53 kHz PWM Frequency (Resolution 10)
  PR2 = 0xff;     // PWM Duty Cycle: 0-1023
}

//-------------------------------------------------------
void SetDCPWM1(unsigned int dutycycle)
{
  union PWMDC DCycle;

  // Save the dutycycle value in the union
  DCycle.lpwm = dutycycle << 6;
  // Write the high byte into CCPR1L
  CCPR1L = DCycle.bpwm[1];
  // Write the low byte into CCP1CON5:4
  CCP1CON = (CCP1CON & 0xCF) | ((DCycle.bpwm[0] >> 2) & 0x30);
}

//-------------------------------------------------------
void SetDCPWM2(unsigned int dutycycle)
{
  union PWMDC DCycle;

  // Save the dutycycle value in the union
  DCycle.lpwm = dutycycle << 6;
  // Write the high byte into CCPR1L
  CCPR2L = DCycle.bpwm[1];
  // Write the low byte into CCP1CON5:4
  CCP2CON = (CCP2CON & 0xCF) | ((DCycle.bpwm[0] >> 2) & 0x30);
}