/*-------------------------------------------------------
* File    : lcd_i2c.h
* Purpose : IIC/I2C/TWI 1602 Serial LCD Module Display
* Author  : Prajin Palangsantikul
* Ref     : LCD_I2C_SAINSMART_DRIVER (http://elger.org/wiki/)
-------------------------------------------------------*/

#include <xc.h>
#include <string.h>

#define _XTAL_FREQ 20000000
#include "i2c.h"

typedef char                int8;
typedef unsigned char       uint8_t;

#define BLINK               0x01   	// Alias for blinking cursor
#define NOBLINK             0x00   	// Alias for non blinking cursor
#define SHOW                0x02   	// Alias for cursor on
#define HIDE                0x00   	// Alias for cursor off
#define ON                  0x04   	// Alias for display on
#define OFF                 0x00   	// Alias for display off
#define CLS                 0x01        // Clear LCD

// Line addresses for LCDs which use the Hitachi HD44780U controller chip
#define LCD_PIC_LINE_1_ADDRESS      0x00
#define LCD_PIC_LINE_2_ADDRESS      0x40
#define LCD_PIC_LINE_3_ADDRESS      0x14
#define LCD_PIC_LINE_4_ADDRESS      0x54
//

// Line addresses for LCDs which use the Hitachi HD66712U controller chip
/*
#define LCD_PIC_LINE_1_ADDRESS 0x00
#define LCD_PIC_LINE_2_ADDRESS 0x20
#define LCD_PIC_LINE_3_ADDRESS 0x40
#define LCD_PIC_LINE_4_ADDRESS 0x60
*/

// 1 for POSITIVE control, 0 for NEGATIVE control
#define  BL_ON          1       
// Sainsmart I2C adapter LCD2004
#define  LCD_PIC_addr   0x27    
// Following line creates appropriate address byte for I2C interface (shift left 1-bit)
#define lcd_i2c_ADDR (LCD_PIC_addr<<1)
// Fixed delay to allow LCD to process I2C instruction
#define lcd_fixed_delay_us      50  

void lcd_i2c_Init();
void lcd_i2c_Gotoxy(int8 x, int8 y);
void lcd_i2c_Putc(char c);
void lcd_i2c_Write(char text[]);
void lcd_i2c_Send_Byte(int8 mode, int8 n);
void lcd_i2c_Write_Upper_Nibble(int u);
void lcd_i2c_Write_Lower_Nibble(int l);

typedef struct tagI2CBITS {
  union {
    struct {
        unsigned RS:1;    //bit.0
        unsigned RW:1;    //bit.1
        unsigned E:1;     //bit.2
        unsigned BL:1;    //bit.3
        unsigned D4:1;    //bit.4
        unsigned D5:1;    //bit.5
        unsigned D6:1;    //bit.6
        unsigned D7:1;    //bit.7
        };
    struct {
        unsigned i2cbyte;
       };
  };
}I2CBITS;
I2CBITS I2Cbits;

int LCD_PIC_line;

//-------------------------------------------------------
void lcd_i2c_Init()
{
   // Initialization commands for Hitachi HD44780U LCD Display
   //
   __delay_ms(300);                               // Let LCD power up

   i2c_WriteTo(lcd_i2c_ADDR);

   // Following bytes are all Command bytes, i.e. address = 0x00
   lcd_i2c_Send_Byte(0x00, 0x03);       // Write Nibble 0x03 three times (per HD44780U initialization spec)
   __delay_us(lcd_fixed_delay_us);      // (per HD44780U initialization spec)
   lcd_i2c_Send_Byte(0x00, 0x03);       //
   __delay_us(lcd_fixed_delay_us);      // (per HD44780U initialization spec)

   lcd_i2c_Send_Byte(0x00, 0x03);       //
   __delay_us(lcd_fixed_delay_us);      // (per HD44780U initialization spec)
   lcd_i2c_Send_Byte(0x00, 0x02);       // Write Nibble 0x02 once (per HD44780U initialization spec)
   __delay_us(lcd_fixed_delay_us);      // (per HD44780U initialization spec)

   lcd_i2c_Send_Byte(0x00, 0x28);       // Set mode: 4-bit, 2+lines, 5x8 dots
   __delay_us(lcd_fixed_delay_us);      // (per HD44780U initialization spec)

   lcd_i2c_Send_Byte(0x00, 0x0C);       // Display ON
   __delay_us(lcd_fixed_delay_us);      // (per HD44780U initialization spec)

   lcd_i2c_Send_Byte(0x00, 0x01);       // Clear display
   __delay_ms(lcd_fixed_delay_us);      // (per HD44780U initialization spec)

   lcd_i2c_Send_Byte(0x00, 0x06);       // Set cursor to increment
   __delay_us(lcd_fixed_delay_us);      // (per HD44780U initialization spec)

   i2c_Stop();                           // Terminate I2C transfer
}

//-------------------------------------------------------
void lcd_i2c_Write(char text[])
{
   int lcd_j,lcd_max,lcd_tempbyte;

   // Writes a string text[] to LCD via I2C
   I2Cbits.RS  = 1;
   I2Cbits.RW  = 0;
   I2Cbits.E   = 0;
   I2Cbits.BL  = BL_ON;
   
   i2c_WriteTo(lcd_i2c_ADDR);

   lcd_max=strlen(text);
   for(lcd_j=0; lcd_j<lcd_max; ++lcd_j)
   {
      lcd_tempbyte=text[lcd_j];
      // Send upper nibble
      lcd_i2c_Write_Upper_Nibble(lcd_tempbyte);
      // Send lower nibble
      lcd_i2c_Write_Lower_Nibble(lcd_tempbyte);
   }
   
   i2c_Stop();
}

//-------------------------------------------------------
void lcd_i2c_Gotoxy(int8 x, int8 y)
{
   int8 address;

   switch(y) {
      case 1:
        address = LCD_PIC_LINE_1_ADDRESS;
        break;
      case 2:
        address = LCD_PIC_LINE_2_ADDRESS;
        break;
      case 3:
        address = LCD_PIC_LINE_3_ADDRESS;
        break;
      case 4:
        address = LCD_PIC_LINE_4_ADDRESS;
        break;
      default:
        address = LCD_PIC_LINE_1_ADDRESS;
        break;     
     }

   address += x-1;
   lcd_i2c_Send_Byte(0, 0x80 | address);
}

//-------------------------------------------------------
void lcd_i2c_Putc(char c)
{
   // Writes a char 'c' to LCD via I2C to include some common formats
   switch(c)
   {
      case '\f':
         lcd_i2c_Send_Byte(0x00,0x01);
         LCD_PIC_line = 1;
         __delay_ms(lcd_fixed_delay_us);
         break;
      case '\n':
          lcd_i2c_Send_Byte(0x01, ++LCD_PIC_line);
          break;
      
      case '\b':
          lcd_i2c_Send_Byte(0x00,0x10);
          break;
      
      default:
          lcd_i2c_Send_Byte(0x01,c);
          break;
   }
}

//-------------------------------------------------------
void lcd_i2c_Send_Byte(int8 mode, int8 n)
{
   // HD44780U LCD Address Type (RS): Command=0, Data=1
   //
   if(mode)
      I2Cbits.RS = 1;   // Data
   else
      I2Cbits.RS = 0;   // Command
 
   I2Cbits.RW  = 0;
   I2Cbits.E   = 0;
   I2Cbits.BL  = BL_ON;
   
   i2c_WriteTo(lcd_i2c_ADDR);

   // Send upper nibble
   lcd_i2c_Write_Upper_Nibble(n);

   // Send lower nibble
   lcd_i2c_Write_Lower_Nibble(n);
   
   i2c_Stop();
   //delay_ms(lcd_fixed_delay_us);
}

//-------------------------------------------------------
int bit_test(unsigned char u, int n)
{
    u = u >> n;
    u = u & 0x01;
    return (u);
}

//-------------------------------------------------------
void lcd_i2c_Write_Upper_Nibble(int u)
{
   // Send upper nibble
   if(bit_test(u,7))    I2Cbits.D7=1;  else    I2Cbits.D7=0;
   if(bit_test(u,6))    I2Cbits.D6=1;  else    I2Cbits.D6=0;
   if(bit_test(u,5))    I2Cbits.D5=1;  else    I2Cbits.D5=0;
   if(bit_test(u,4))    I2Cbits.D4=1;  else    I2Cbits.D4=0;

   I2Cbits.E = 0;
   i2c_PutByte(I2Cbits.i2cbyte);
   I2Cbits.E = 1;
   i2c_PutByte(I2Cbits.i2cbyte);
   I2Cbits.E = 0;
   i2c_PutByte(I2Cbits.i2cbyte);
}

//-------------------------------------------------------
void lcd_i2c_Write_Lower_Nibble(int l)
{
   // Send lower nibble
   if(bit_test(l,3))    I2Cbits.D7=1;  else    I2Cbits.D7=0;
   if(bit_test(l,2))    I2Cbits.D6=1;  else    I2Cbits.D6=0;
   if(bit_test(l,1))    I2Cbits.D5=1;  else    I2Cbits.D5=0;
   if(bit_test(l,0))    I2Cbits.D4=1;  else    I2Cbits.D4=0;

   I2Cbits.E = 0;
   i2c_PutByte(I2Cbits.i2cbyte);
   I2Cbits.E = 1;
   i2c_PutByte(I2Cbits.i2cbyte);
   I2Cbits.E = 0;
   i2c_PutByte(I2Cbits.i2cbyte);
}

