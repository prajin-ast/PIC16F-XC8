/*-------------------------------------------------------
* File    : LAB_0904.c
* Purpose : FLASH Memory
* Author  : Prajin Palangsantikul
-------------------------------------------------------*/
#include <xc.h>

#define _XTAL_FREQ 20000000
#pragma config FOSC = HS, WDTE = OFF, CP = OFF, LVP = OFF
	
#include "flashcopy.c"  // Flash Copy function

//-------------------------------------------------------
void main (void)
{   
  int i;
  unsigned char data[5];
  
  for(i = 0; i< 20; i++)
  {
    flash_copy( &i, 1, 0x810+i ); // write flash
  }
 
  data[0] = FLASH_READ(0x814);    // read flash
  data[1] = FLASH_READ(0x815);
  data[2] = FLASH_READ(0x816);
  data[3] = FLASH_READ(0x817);
  data[4] = FLASH_READ(0x818);
  
  while (1);

}

