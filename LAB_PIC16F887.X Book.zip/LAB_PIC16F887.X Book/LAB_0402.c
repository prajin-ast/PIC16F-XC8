/*-------------------------------------------------------
* File    : LAB05_02.c
* Purpose : Timer0 (Counter mode)
* Author  : Prajin Palangsantikul
-------------------------------------------------------*/
#include <xc.h>

#define _XTAL_FREQ 20000000
#pragma config FOSC = HS, WDTE = OFF, LVP = OFF

#define CNT_TICK  (256-2)
#define CNT_MS    200

char c0_process = 0;

//-------------------------------------------------------
// Interrupt function all
void __interrupt() isr(void)
{
  if (T0IE && T0IF)	// Timer0 Overflow Interrupt Flag
  {
    c0_process = 1;
    T0IF = 0;  // Clear interrupt flag
    TMR0 = CNT_TICK;
  }
}

//-------------------------------------------------------
void main(void)
{
  int cnt_ms = CNT_MS;
  int process = 1;
	
  TRISD = 0;  // PORTB as output
  PORTD = 0;  // Clear port
 
  // Setup Timer0
  T0CS = 1;   // Transition on T0CKI pin (RA4)
  T0SE = 0;   // Increment on low-to-high transition on T0CKI pin
  PSA = 1;    // Prescaler is assigned to the WDT
  PS0 = 0;    // Prescaler Rate Select PS0-PS2 (1:1)
  PS1 = 0;    // 
  PS2 = 0;    // 
  TMR0 = CNT_TICK;
  
  // Configuration Timer0 Interrupt
  T0IE = 1;   // Enables the Timer0 interrupt
  T0IF = 0;   // Clear Timer0 interrupt flag
  PEIE = 1;   // Enables all unmasked peripheral interrupts
  GIE = 1;    // Enables all unmasked interrupts
	  	  
	while (1)
	{
    if (cnt_ms-- <= 0)
    {
      cnt_ms = CNT_MS;
      if (process == 1) 
      {
        PORTD = 0b00000001;
      } 
      else if (process == 2)
      {
        PORTD = 0b00000010;
      }
      else if (process == 3)
      {
        PORTD = 0b00000100;
      }
      else if (process == 4)
      {
        PORTD = 0b00001000;  	  
      }
      if (process++ > 4)  // Next process
      {
        process = 1;
      }
    } else {
      __delay_ms(1);
    }
    if (c0_process == 1)
    {
      PORTD = 0xff;
      c0_process = 0;
    }
  }	
}
