/*-------------------------------------------------------
* File    : LAB_1002_01.c
* Purpose : CCP1 (Ouput compare, "CCP1M=1010")
* Author  : Prajin Palangsantikul
-------------------------------------------------------*/
#include <xc.h>

#define _XTAL_FREQ 20000000
#pragma config FOSC = HS, WDTE = OFF, LVP = OFF

//-------------------------------------------------------
// Interrupt function
void __interrupt() isr(void)			
{
  static char toggle_bit = 0;
   
	if (CCP1IE && CCP1IF) // CCP1 Interrupt Flag bit
  {      
    toggle_bit = !toggle_bit;
    RB0 = toggle_bit;
    CCP1IF = 0;         // Clear the interrupt
    TMR1 = 0;           // Clear TMR1
  }
}

//-------------------------------------------------------
void main (void)
{   
  TRISA0 = 0; // Output
  TRISB0 = 0; // Output
  TRISC2 = 0; // Set RC2/CCP1 Output

  // Setup Timer1, 1:8 Prescale value
  T1CON = 0b00110001;
  TMR1 = 0;

  // Compare mode, generate software interrupt on match
  CCP1CON = 0b00001010;
  CCPR1 = 0x2fff;

  // CCP1 Interrupt
  CCP1IE = 1;	// CCP1 Interrupt Enable bit
  CCP1IF = 0;	// CCP1 Interrupt Flag bit
  PEIE = 1;   // Peripheral Interrupt Enable bit
  GIE = 1;    // Global interrupt enable

  while (1)
  {
    RC2 = 1; RA0 = 0;  
    __delay_ms(100);
    RC2 = 0; RA0 = 1;  
    __delay_ms(100);
  }
}





