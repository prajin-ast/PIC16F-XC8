/*-------------------------------------------------------
* File    : LAB_0905_04.c
* Purpose : 
* Author  : Prajin Palangsantikul
-------------------------------------------------------*/
#include <xc.h>

#define _XTAL_FREQ 20000000
#pragma config FOSC = HS, WDTE = OFF, LVP = OFF

//-------------------------------------------------------
void main (void)
{   
    unsigned int data;
    unsigned short address=0x1000;

    data = flash_read(address);
    flash_erase(address);
}
